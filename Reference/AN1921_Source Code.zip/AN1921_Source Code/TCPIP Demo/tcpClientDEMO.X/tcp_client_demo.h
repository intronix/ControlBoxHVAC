#ifndef TCP_clientDemo_H
#define TCP_clientDemo_H

void DEMO_TCP_Client(void);

void TCP_Client_Initialize(void);

#endif